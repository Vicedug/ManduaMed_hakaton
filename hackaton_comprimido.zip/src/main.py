from gestor import guardar_medicamento, obtener_recetas

# Prueba rápida
guardar_medicamento("Ibuprofeno", "14:00", "1 tableta")
print(obtener_recetas())